package br.com.garagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GaragemTests {

	@Test
	void contextLoads() {
	}

}
